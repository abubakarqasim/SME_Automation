package tests;


import base.SMETest;
import org.testng.annotations.Test;

public class CnfrmPack extends SMETest {

    @Test
    public void confirmPageTest()
    {
        reports.logTestNameAndDescription("ConfirmPackage" , "SME Automation");
        confirmPackage.ConfirmPack();
        reports.logPassedTestSteps("Passed");

    }


}
