package tests;


import base.SMETest;
import org.apache.hc.core5.reactor.Command;
import org.testng.annotations.Test;

public class CnfrmPack extends SMETest {

//    @Test
    public void confirmPageTest()
    {
        reports.logTestNameAndDescription("ConfirmPackage" , "SME Automation");
        confirmPackage.ConfirmPack();
        reports.logPassedTestSteps("Passed");

    }
   // @Test (priority = 0)
    public void LoadingPageTestDown() throws InterruptedException {
        reports.logTestNameAndDescription("LoadingPageScrollDown" , "SME Automation");
        loadingPage.ScrollDown();
        reports.logPassedTestSteps("Passed");

    }
    //@Test (priority = 1)
    public void LoadingPageTestUp() throws InterruptedException {
        reports.logTestNameAndDescription("LoadingPageScrollUp" , "SME Automation");
        loadingPage.ScrollUp();
        reports.logPassedTestSteps("Passed");

    }
@Test (priority = 2)
    public void ClientSupport() throws InterruptedException {
        reports.logTestNameAndDescription("ClientSupport" , "SME Automation");
        customerSupport.ClientSupport();
        reports.logPassedTestSteps("Passed");

    }





}
