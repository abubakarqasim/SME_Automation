package base;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import pages.ConfirmPackage;
import pages.CustomerSupport;
import pages.LoadingPage;
import utilities.Reports.Report;

public class SMETest {

    WebDriver driver;

    protected ConfirmPackage confirmPackage;
    protected Report reports;

    protected LoadingPage loadingPage;
    protected CustomerSupport customerSupport;

    @BeforeClass
    public void setUp() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        confirmPackage = new ConfirmPackage(driver);
        reports = new Report(driver);
        loadingPage = new LoadingPage(driver);
        customerSupport = new CustomerSupport(driver);
        driver.manage().window().fullscreen();
        driver.get("https://sme-web-portal-qa.mvola.mg/#/sales");
//        driver.manage().window().fullscreen();
        reports.extentReporter();

    }

    @AfterClass
    public void tearDown() {
        reports.flushExtentReport();
        driver.quit();
    }
}
